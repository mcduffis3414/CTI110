s = int(input())
m = int(input())

if m >= s:
    for i in range(s, m+1, 5,):
        print(i, end=' ')
    print()
else:
    print('Second integer can\'t be less than the first.')